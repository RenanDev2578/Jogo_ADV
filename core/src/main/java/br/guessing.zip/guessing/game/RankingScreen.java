package br.guessing.game;

public class RankingScreen {
}
